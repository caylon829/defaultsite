<?php

/**
 * 支付接口配置
 */

return [
    
    'name' => '微信',
    'icon' => '<i class="fa fa-weixin"></i>',
    
];