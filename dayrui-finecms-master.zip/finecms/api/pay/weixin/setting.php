<div class="form-group">
    <label class="col-md-2 control-label">AppId</label>
    <div class="col-md-9">
        <input type="text" class="form-control input-large" name="data[<?php echo $dir;?>][appid]" value="<?php echo $data[$dir]['appid']?>" >
    </div>
</div>
<div class="form-group">
    <label class="col-md-2 control-label">AppSecret</label>
    <div class="col-md-9">
        <input type="text" class="form-control input-large" name="data[<?php echo $dir;?>][appsecret]" value="<?php echo $data[$dir]['appsecret']?>" >
    </div>
</div>
<div class="form-group">
    <label class="col-md-2 control-label">MCHID</label>
    <div class="col-md-9">
        <input type="text" class="form-control input-large" name="data[<?php echo $dir;?>][mchid]" value="<?php echo $data[$dir]['mchid']?>" >
    </div>
</div>
<div class="form-group">
    <label class="col-md-2 control-label">KEY</label>
    <div class="col-md-9">
        <input type="text" class="form-control input-large" name="data[<?php echo $dir;?>][key]" value="<?php echo $data[$dir]['key']?>" >
    </div>
</div>