<?php

/**
 * 支付接口配置
 */

return [
    
    'name' => '上门付款',
    'icon' => '<i class="icon iconfont icon-caifua"></i>',
    
];