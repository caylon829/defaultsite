<?php

/**
 * 支付接口配置
 */

return [
    
    'name' => '余额',
    'icon' => '<i class="icon iconfont icon-yiban"></i>',
    
];