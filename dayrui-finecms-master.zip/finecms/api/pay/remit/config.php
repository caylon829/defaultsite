<?php

/**
 * 支付接口配置
 */

return [
    
    'name' => '银行汇款',
    'icon' => '<i class="icon iconfont icon-duozhongzhifu"></i>',
    
];