<?php

return [

    'type' => 'module',
    'name' => '论坛',
    'icon' => 'fa fa-comments',
    'system' => '1',

];