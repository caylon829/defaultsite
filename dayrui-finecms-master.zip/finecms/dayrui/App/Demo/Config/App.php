<?php

return [

    'type' => 'module',
    'name' => '示例',
    'icon' => 'fa fa-reorder',
    'system' => '1',

];