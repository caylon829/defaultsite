<?php namespace Phpcmf\Controllers;

class Home extends \Phpcmf\Home\Module
{

	public function index() {
		$this->_Index();
	}

}
