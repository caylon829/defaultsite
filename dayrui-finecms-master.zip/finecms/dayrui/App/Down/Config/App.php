<?php

return [

    'type' => 'module',
    'name' => '下载',
    'icon' => 'fa fa-download',
    'system' => '1',

];