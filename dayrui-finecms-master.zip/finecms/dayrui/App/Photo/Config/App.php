<?php

return [

    'type' => 'module',
    'name' => '图片',
    'icon' => 'fa fa-photo',
    'system' => '1',

];